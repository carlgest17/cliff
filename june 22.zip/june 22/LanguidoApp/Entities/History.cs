﻿using System;
using System.Collections.Generic;

namespace LanguidoApp.Entities
{
    public partial class History
    {
        public int Historyid { get; set; }
        public int Productid { get; set; }
        public int Stock { get; set; }
        public string Historylog { get; set; }
        public int AddedStock { get; internal set; }
        public int ProdId { get; internal set; }
        public string Date { get; internal set; }
    }
}
