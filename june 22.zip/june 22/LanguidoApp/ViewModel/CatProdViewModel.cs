namespace LanguidoApp.ViewModel
{
    public class CatProdViewModel
    {
        public int Prodid { get; set; }
        public string Category { get; set; } = null!;

        public string CategoryName { get; set; } = null!;
        public string Prodname { get; set; } = null!;
        public string Units { get; set; } = null!;
        public string Stock { get; set; } = null!;
        public string Price { get; set; } = null!;
        public string Status { get; set; } 
    }
}