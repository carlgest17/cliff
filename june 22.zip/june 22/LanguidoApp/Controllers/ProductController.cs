// using System;
// using System.Collections.Generic;
// using System.Linq;
// using System.Threading.Tasks;
// using Microsoft.AspNetCore.Mvc;
// using Microsoft.AspNetCore.Mvc.Rendering;
// using Microsoft.EntityFrameworkCore;
// using LanguidoApp.Entities;
// using LanguidoApp.ViewModel;

// namespace LanguidoApp.Controllers
// {
//     public class ProductController : Controller
//     {
//         private readonly languidoContext _context;

//         public ProductController(languidoContext context)
//         {
//             _context = context;
//         }

//         // GET: Product
//         public async Task<IActionResult> Index()
//         {
//              var result = (
//                 from p in _context.Products
//                 join c in _context.Categories
//                 on p.Category equals c.Id.ToString() // naka base siya table if int ba or sting kung int mag tostring ka

//                 select new CatProdViewModel
//                 {

                   
//                     Prodid = p.Prodid,
//                     Category = p.Category,
//                     CategoryName = c.Name,
//                     Prodname = p.Prodname,
//                     Stock = p.Stock.ToString(),
//                     Status = p.Status,
//                     Price = p.Price,
//                     Units = p.Units
//                 }



//             ).ToList();
//             return View(result);
//         }
//          public async Task<IActionResult> History(int? id)
//         {

//              if (id == null)
//             {
//                 return NotFound();
//             }

          
//             var history = await _context.Histories
//             .Where(m => m.Productid == id).ToListAsync();

//             if (history == null)
//             {
//                 return NotFound();
//             }

           

//             return View(history );
           
//         }

//         // GET: Product/Details/5
//         public async Task<IActionResult> Details(int? id)
//         {
//             if (id == null)
//             {
//                 return NotFound();
//             }

//             var product = await _context.Products
//                 .FirstOrDefaultAsync(m => m.Prodid == id);
//             if (product == null)
//             {
//                 return NotFound();
//             }

//             return View(product);
//         }

//         // GET: Product/Create
//         public IActionResult Create()
//         {
//             ViewBag.categories = _context.Categories.ToList()
//             .Select(x => new SelectListItem { Text = x.Name, Value = x.Id.ToString() });
//             return View();
//         }

//         // POST: Product/Create
//         // To protect from overposting attacks, enable the specific properties you want to bind to.
//         // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
//         [HttpPost]
//         [ValidateAntiForgeryToken]
//         public async Task<IActionResult> Create([Bind("Prodid,Category,Prodname,Units,Stock,Price,Status")] Product product)
//         {
//               if (ModelState.IsValid)
//             {
//                 if (string.IsNullOrEmpty(product.Status) || product.Status == "false")

//                     product.Status = "Unavailable";

//                 _context.Add(product);
//                 await _context.SaveChangesAsync();
//                 return RedirectToAction(nameof(Index));

//             }
//             return View(product);
//         }

//         // GET: Product/Edit/5
//         public async Task<IActionResult> Edit(int? id)
//         {
//            if (id == null)
//             {
//                 return NotFound();
//             }

       
//             ViewBag.categories = _context.Categories.ToList()
//             .Select(x => new SelectListItem { Text = x.Name, Value = x.Id.ToString() });

          
//             var product = await _context.Products.FindAsync(id);
//             if (product == null)
//             {
//                 return NotFound();
//             }
//             return View(product);
//         }

//         // POST: Product/Edit/5
//         // To protect from overposting attacks, enable the specific properties you want to bind to.
//         // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
//         [HttpPost]
//         [ValidateAntiForgeryToken]
//         public async Task<IActionResult> Edit(int id, [Bind("Prodid,Category,Prodname,Units,Stock,Price,Status")] Product product)
//         {
//             if (id != product.Prodid)
//             {
//                 return NotFound();
//             }

          
//                 try
//                 {
//                     if(string.IsNullOrEmpty(product.Status) || product.Status == "false"){
//                      product.Status = "Unavailable";
//                     }
//                     else{
//                      product.Status = "Available";
//                     }
//                     _context.Update(product);
//                     await _context.SaveChangesAsync();
//                 }
//                 catch (DbUpdateConcurrencyException)
//                 {

//                     if (!ProductExists(product.Prodid))
//                     {
//                         return NotFound();
//                     }
//                     else
//                     {
//                         throw;
//                     }
//                 }
//                 return RedirectToAction(nameof(Index));
            
//          return View(product);
//         }

//         // GET: Product/Delete/5
//         public async Task<IActionResult> Delete(int? id)
//         {
//             if (id == null)
//             {
//                 return NotFound();
//             }

//             var product = await _context.Products
//                 .FirstOrDefaultAsync(m => m.Prodid == id);
//             if (product == null)
//             {
//                 return NotFound();
//             }

//             return View(product);
//         }

//         // POST: Product/Delete/5
//         [HttpPost, ActionName("Delete")]
//         [ValidateAntiForgeryToken]
//         public async Task<IActionResult> DeleteConfirmed(int id)
//         {
//             var product = await _context.Products.FindAsync(id);
//             _context.Products.Remove(product);
//             await _context.SaveChangesAsync();
//             return RedirectToAction(nameof(Index));
//         }

//         private bool ProductExists(int id)
//         {
//             return _context.Products.Any(e => e.Prodid == id);
//         }
//           public async Task<IActionResult> AddStock(int? id)
//         {
//             if (id == null)
//             {
//                 return NotFound();
//             }

//              ViewBag.categories = _context.Categories.ToList()
//             .Select(x => new SelectListItem { Text = x.Name, Value = x.Id.ToString() }); 

//             var product = await _context.Products.FindAsync(id);

//             if (product == null)
//             {
//                 return NotFound();
//             }

//             return View(product);
//         }


//         [HttpPost]
//         [ValidateAntiForgeryToken]
//         public async Task<IActionResult> AddStock(int id, [Bind("Prodid,Category,Prodname,Units,Stock,Price,Status")] Product product,int  kanistock)
//         {
//             if (id != product.Prodid)
//             {
//                 return NotFound();
//             }

//             if (ModelState.IsValid)
//             {
//                 try
//                 {
//                     //usbon ang stock
//                     product.Stock += kanistock;

//                     _context.Update(product);
//                     await _context.SaveChangesAsync();

//                     //converting string to int
                    

//                     DateTime dt = DateTime.Now;
//                     History newhistory = new History();
//                     newhistory.Historyid = default;
//                     newhistory.Productid  = product.Prodid;
//                     newhistory.Stock = kanistock;
//                     newhistory.Historylog = dt+"| Added "+kanistock+" stock for " +product.Prodname;

//                      _context.Add(newhistory);
//                     await _context.SaveChangesAsync();
                    
//                 }
//                 catch (DbUpdateConcurrencyException)
//                 {
                   
//                     if (!ProductExists(product.Prodid))
//                     {
//                         return NotFound();
//                     }
//                     else
//                     {
//                         throw;
//                     }
//                 }
//                 return RedirectToAction(nameof(Index));
//             }
//             return View(product);
//         }
//     }
// }
