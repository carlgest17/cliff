-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2023 at 03:29 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `semi`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Milk'),
(8, 'Bread'),
(9, 'Chocolate'),
(11, 'Ice Cream');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `category` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `units` varchar(250) NOT NULL,
  `stock` int(11) NOT NULL,
  `price` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `category`, `name`, `units`, `stock`, `price`, `status`) VALUES
(30, '1', 'da', 'a', 104, '66', 'Active'),
(31, '1', 'ds', 's', 118, '66', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `stockhistory`
--

CREATE TABLE `stockhistory` (
  `a_Stock_ID` int(11) NOT NULL,
  `prodID` int(11) NOT NULL,
  `added_stock` int(11) NOT NULL,
  `date` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stockhistory`
--

INSERT INTO `stockhistory` (`a_Stock_ID`, `prodID`, `added_stock`, `date`) VALUES
(15, 13, 2, '5/4/2023 4:46:18 PM'),
(16, 13, 5, '5/19/2023, 12:40:08 AM'),
(17, 15, 1, '5/19/2023, 11:06:03 PM'),
(18, 15, 2, '5/20/2023, 12:06:11 AM'),
(19, 15, 2, '5/20/2023, 12:06:11 AM'),
(20, 15, 1, '5/20/2023, 12:24:41 AM'),
(21, 22, 5, '5/20/2023, 1:13:12 AM'),
(22, 22, 6, '5/20/2023, 1:13:22 AM'),
(23, 22, 7, '5/20/2023, 1:13:33 AM'),
(24, 22, 2, '5/20/2023, 1:15:19 AM'),
(25, 22, 1, '5/20/2023, 1:15:49 AM'),
(26, 30, 1, '5/20/2023, 1:46:50 AM'),
(27, 30, 3, '5/20/2023, 1:47:43 AM'),
(28, 30, 3, '5/20/2023, 1:47:43 AM'),
(29, 31, 5, '5/20/2023, 6:59:36 AM'),
(30, 31, 5, '5/20/2023, 6:59:41 AM'),
(31, 31, 5, '5/20/2023, 6:59:41 AM'),
(32, 31, 1, '5/20/2023, 7:00:56 AM'),
(33, 31, 1, '5/20/2023, 7:03:40 AM'),
(34, 31, 1, '5/20/2023, 7:07:14 AM'),
(35, 31, 1, '5/20/2023, 7:07:19 AM'),
(36, 31, 1, '5/20/2023, 7:07:19 AM'),
(37, 31, 1, '5/20/2023, 7:08:59 AM'),
(38, 31, 2, '5/20/2023, 7:09:04 AM'),
(39, 31, 1, '5/20/2023, 7:09:17 AM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stockhistory`
--
ALTER TABLE `stockhistory`
  ADD PRIMARY KEY (`a_Stock_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `stockhistory`
--
ALTER TABLE `stockhistory`
  MODIFY `a_Stock_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
